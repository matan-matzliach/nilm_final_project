package com.example.nilmapp0;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface RetrofitClient {
    @FormUrlEncoded
    @POST("nilmgraph_power")
    Call<PostGraph> createPost(@FieldMap Map<String, String> fields);
    @POST("nilmgraph_cost")
    Call<CostPost> createPostCost(@Body CostPost p);
    @POST("nilmgraph_devices")
    Call<DevicesPostplot> createPostDevice(@Body DevicesPostplot p);
    @FormUrlEncoded
    @POST("app")
    Call<Post> sendAck(@FieldMap Map<String, String> fields);

    @GET("get_device_list")
    Call<List<DevicePost>> getDevicePosts();
    @POST("add_device_json")
    Call<DevicePost> add_device(@Body DevicePost p);
    @POST("remove_device_json")
    Call<removePost> remove_device(@Body removePost p);
    //@GET("{imageName}")
    //void getImage(@Path("imageName") String imageName, Callback<Response> callback);
}
