package com.example.nilmapp0;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Add_device extends AppCompatActivity {
    private TextView servers_ans;
    private boolean added;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_device);
        runLoop();
            }
    protected void runLoop(){
        EditText text = (EditText)findViewById(R.id.add_or_rem);
        servers_ans = (TextView) findViewById(R.id.answer_to_add_rem);
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(getString(R.string.server_ip))
                .addConverterFactory(GsonConverterFactory.create())
                .client(getUnsafeOkHttpClient())
                .build();
        RetrofitClient rfc=retrofit.create(RetrofitClient.class);
        Map<String, String> fields = new HashMap<>();
        Call<Post> call = rfc.sendAck(fields);
        System.out.println("DDDDDDDDDDDDDDDDDDDDDDD");
        call.enqueue(new Callback<Post>() {
            @Override
            public void onResponse(Call<Post> call, Response<Post> response) {
                System.out.println("JHJH"+response);
                if (!response.isSuccessful()) {
                    return;
                }
                Post posts = response.body();
                System.out.println("RRRRR" + posts);
                System.out.println("AAAA" + posts.getNeeded());
                if (posts.getNeeded().equals("yes")) {
                    System.out.println("STARTEDDDDD");
                    DevicePost p = posts.getDev();
                    added = false;
                    String content = "";
                    content += "Current: " + String.valueOf(p.getCurrent()) + "\n";
                    content += "Current THD: " + String.valueOf(p.getCurrent_THD()) + "\n";
                    content += "Power: " + String.valueOf(p.getCurrent()*230) + "\n";
                    //content += "Phase: [" + String.valueOf(p.getPhase0()) + "," + String.valueOf(p.getPhase1()) + "," + String.valueOf(p.getPhase2()) + "]" + "\n";
                    servers_ans.setText(content);
                    Button add = (Button) findViewById(R.id.add);
                    add.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            String value = text.getText().toString();
                            System.out.println("OOOOOOO");
                            p.setName(value);
                            System.out.println("OOOOOOO");
                            Call<DevicePost> call2 = rfc.add_device(p);
                            System.out.println("OOOOOOO");
                            call2.enqueue(new Callback<DevicePost>() {
                                @Override
                                public void onResponse(Call<DevicePost> call, Response<DevicePost> response) {
                                    if (!response.isSuccessful()) {
                                        System.out.println("TINYY" + response);
                                        return;
                                    }
                                    if(response.body().getName().equals(value)){
                                        servers_ans.setText("Device Added to list successfully");
                                    }
                                    else{
                                        String respadd = "";
                                        respadd+="Device ";
                                        respadd+=value;
                                        respadd+=" already exists try a different name";
                                        servers_ans.setText(respadd);
                                    }
                                    runLoop();
                                    }
                                    @Override
                                    public void onFailure(Call<DevicePost> call, Throwable t) {
                                        System.out.println("TINYYYYYYYYYYYYYYYYYYTTTT");

                                    }
                                });
                            }
                        });
                    }
                else{
                    servers_ans.setText("No new device detected");
                }
                }

            @Override
            public void onFailure(Call<Post> call, Throwable t) {

            }
        });
    }

    //the following function is used to make the app ignore the fact our server doesn't have certificate.
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
