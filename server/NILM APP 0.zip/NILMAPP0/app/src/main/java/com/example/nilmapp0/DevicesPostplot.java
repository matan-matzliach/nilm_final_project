package com.example.nilmapp0;

import java.util.ArrayList;

public class DevicesPostplot {
    private String starttime;
    private String endtime;
    private ArrayList<String> devices_to_plot;

    public DevicesPostplot(String starttime, String endtime, ArrayList<String> devices_to_plot) {
        this.starttime = starttime;
        this.endtime = endtime;
        this.devices_to_plot = devices_to_plot;
    }

    @Override
    public String toString() {
        return "DevicesPostplot{" +
                "starttime='" + starttime + '\'' +
                ", endtime='" + endtime + '\'' +
                ", devices_to_plot=" + devices_to_plot +
                '}';
    }

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public ArrayList<String> getDevices_to_plot() {
        return devices_to_plot;
    }

    public void setDevices_to_plot(ArrayList<String> devices_to_plot) {
        this.devices_to_plot = devices_to_plot;
    }
}
