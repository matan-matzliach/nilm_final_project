package com.example.nilmapp0;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class DeviceListActivity extends AppCompatActivity {

    private TextView textViewResult;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_device_list);
        textViewResult = findViewById(R.id.text_view_result);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(getString(R.string.server_ip))
                .addConverterFactory(GsonConverterFactory.create())
                .client(getUnsafeOkHttpClient())
                .build();
        RetrofitClient rfc_devlist = retrofit.create(RetrofitClient.class);
        Call<List<DevicePost>> call =rfc_devlist.getDevicePosts();
        call.enqueue(new Callback<List<DevicePost>>() {
            @Override
            public void onResponse(Call<List<DevicePost>> call, Response<List<DevicePost>> response) {
                if (!response.isSuccessful()) {
                    System.out.println("TINYY"+response);
                    return;
                }
                List<DevicePost> posts = response.body();
                for(DevicePost p:posts) {
                    String content = "";
                    content += "Device Name: " + p.getName() + "\n";
                    content += "Current: " + String.valueOf(p.getCurrent()) + "\n";
                    content += "Current THD: " + String.valueOf(p.getCurrent_THD()) + "\n";
                    content += "Power: " + String.valueOf(p.getCurrent()*230) + "\n";
                    //content += "Phase: [" + String.valueOf(p.getPhase0()) + "," + String.valueOf(p.getPhase1()) + "," + String.valueOf(p.getPhase2()) + "]" + "\n";
                    content += "\n\n";
                    textViewResult.append(content);
                }

            }

            @Override
            public void onFailure(Call<List<DevicePost>> call, Throwable t) {
                System.out.println("TINYYYYYYYYYYYYYYYYYYTTTT");

            }
        });
    }
    //the following function is used to make the app ignore the fact our server doesn't have certificate.
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}