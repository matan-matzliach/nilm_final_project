package com.example.nilmapp0;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class AddOrRemoveChooseActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_or_remove_choose);
        Button addcbtn = (Button) findViewById(R.id.addcbtn);
        addcbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(),Add_device.class);
                startActivity(startIntent);
            }
        });
        Button removecbtn = (Button) findViewById(R.id.removecbtn);
        removecbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(),RemoveDevice.class);
                startActivity(startIntent);
            }
        });
    }
}