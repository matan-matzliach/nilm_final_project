package com.example.nilmapp0;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Main2ActivityAbout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_about);
        //launch wikipedia page of NILM
        Button wikibtn = (Button) findViewById(R.id.wikibutton);
        wikibtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent gotowiki = new Intent(Main2ActivityAbout.this,MyWebView.class);
                if(gotowiki.resolveActivity(getPackageManager())!=null){
                    startActivity(gotowiki);
                }
            }
        });
    }

}
