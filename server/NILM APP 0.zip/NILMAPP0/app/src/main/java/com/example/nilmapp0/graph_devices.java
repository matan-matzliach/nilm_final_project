package com.example.nilmapp0;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.EditText;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class graph_devices extends AppCompatActivity {

    private RetrofitClient rfc;
    private String starttime;
    private String endtime;
    private ListView listView;
    private int dl;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_devices);
        dl=0;
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(getString(R.string.server_ip))
                .addConverterFactory(GsonConverterFactory.create())
                .client(getUnsafeOkHttpClient())
                .build();
        RetrofitClient rfc_devlist = retrofit.create(RetrofitClient.class);
        Call<List<DevicePost>> call =rfc_devlist.getDevicePosts();
        listView = (ListView)findViewById(R.id.listView);
        ArrayList<Device> devices= new ArrayList<>();
        call.enqueue(new Callback<List<DevicePost>>() {
            @Override
            public void onResponse(Call<List<DevicePost>> call, Response<List<DevicePost>> response) {
                if (!response.isSuccessful()) {
                    System.out.println("TINYY"+response);
                    return;
                }
                List<DevicePost> posts = response.body();
                for(DevicePost p:posts) {
                    dl++;
                    devices.add(new Device(p.getName(),false));
                    System.out.println(devices.get(dl-1));
                }
                ArrayAdapter<Device> arrayAdapter = new ArrayAdapter<Device>(getApplicationContext(), android.R.layout.simple_list_item_checked , devices);
                listView.setAdapter(arrayAdapter);
                for(int i=0;i< dl; i++ )  {
                    listView.setItemChecked(i, devices.get(i).isUse());
                }
                listView.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        CheckedTextView v = (CheckedTextView) view;
                        boolean currentCheck = v.isChecked();
                        Device dev = (Device) listView.getItemAtPosition(position);
                        dev.setUse(!currentCheck);
                        devices.get(position).setUse(!devices.get(position).isUse());
                    }
                });
                Button btnplot = (Button) findViewById(R.id.btnplot);
                btnplot.setOnClickListener(new View.OnClickListener(){
                    @Override
                    public void onClick(View v){
                        starttime=((EditText)findViewById(R.id.start_time_edittxt)).getText().toString();
                        endtime=((EditText)findViewById(R.id.end_time_edittxt)).getText().toString();
                        ArrayList<String> devices_to_plot= new ArrayList<>();
                        for (Device d:devices){
                            if(d.isUse()){
                                devices_to_plot.add(d.getDeviceName());
                            }
                        }
                        OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
                        rfc=retrofit.create(RetrofitClient.class);
                        Call<DevicesPostplot> call = rfc.createPostDevice(new DevicesPostplot(starttime,endtime,devices_to_plot));
                        call.enqueue(new Callback<DevicesPostplot>() {
                            @Override
                            public void onResponse(Call<DevicesPostplot> call, Response<DevicesPostplot> response) {
                                if (!response.isSuccessful()) {
                                    return;
                                }
                                //Intent startIntent    = new Intent(getApplicationContext(),Image_slider.class);
                                Intent startIntent    = new Intent(getApplicationContext(),graph_devices_plot.class);
                                startActivity(startIntent);
                            }

                            @Override
                            public void onFailure(Call<DevicesPostplot> call, Throwable t) {
                            }
                        });
                    }
                });

            }

            @Override
            public void onFailure(Call<List<DevicePost>> call, Throwable t) {
                System.out.println("TINYYYYYYYYYYYYYYYYYYTTTT");

            }
        });
    }
    //the following function is used to make the app ignore the fact our server doesn't have certificate.
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}