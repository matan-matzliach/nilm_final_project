package com.example.nilmapp0;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;

import java.util.ArrayList;

public class ViewPagerAdaapter extends FragmentStatePagerAdapter {
    private ArrayList<ImageFragmentGraph> fragments= new ArrayList<>();
    private ArrayList<String> titles= new ArrayList<>();
    public ViewPagerAdaapter(@NonNull FragmentManager fm, int behavior) {
        super(fm, behavior);
        titles.add("I");
        titles.add("I THD");
        titles.add("P [Kw]");
        titles.add("P [Kvar]");
    }

    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return titles.get(position);
    }

    @NonNull
    @Override
    public ImageFragmentGraph getItem(int position) {
        return fragments.get(position);
    }

    @Override
    public int getCount() {
        return fragments.size();
    }

    public void setFragments(ArrayList<ImageFragmentGraph> fragments) {
        this.fragments = fragments;
        notifyDataSetChanged();
    }
}
