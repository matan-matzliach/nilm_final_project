package com.example.nilmapp0;

public class DevicePost {
    private String name;
    private float current;
    private float current_THD;
    private int phase0;
    private int phase1;
    private int phase2;

    public DevicePost(String name, float current, float current_THD, int phase0, int phase1, int phase2) {
        this.name = name;
        this.current = current;
        this.current_THD = current_THD;
        this.phase0 = phase0;
        this.phase1 = phase1;
        this.phase2 = phase2;
    }

    @Override
    public String toString() {
        return "DevicePost{" +
                "name='" + name + '\'' +
                ", current=" + current +
                ", current_THD=" + current_THD +
                ", phase0=" + phase0 +
                ", phase1=" + phase1 +
                ", phase2=" + phase2 +
                '}';
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getCurrent() {
        return current;
    }

    public void setCurrent(float current) {
        this.current = current;
    }

    public float getCurrent_THD() {
        return current_THD;
    }

    public void setCurrent_THD(float current_THD) {
        this.current_THD = current_THD;
    }

    public int getPhase0() {
        return phase0;
    }

    public void setPhase0(int phase0) {
        this.phase0 = phase0;
    }

    public int getPhase1() {
        return phase1;
    }

    public void setPhase1(int phase1) {
        this.phase1 = phase1;
    }

    public int getPhase2() {
        return phase2;
    }

    public void setPhase2(int phase2) {
        this.phase2 = phase2;
    }
}