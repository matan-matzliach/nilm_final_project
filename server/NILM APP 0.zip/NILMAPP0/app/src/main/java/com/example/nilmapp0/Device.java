package com.example.nilmapp0;

import java.io.Serializable;

public class Device implements Serializable {
    private String deviceName;
    private boolean use;

    @Override
    public String toString() {
        return deviceName;
    }

    public Device(String deviceName, boolean use) {
        this.deviceName = deviceName;
        this.use = use;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public boolean isUse() {
        return use;
    }

    public void setUse(boolean use) {
        this.use = use;
    }
}
