package com.example.nilmapp0;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class graph_orig extends AppCompatActivity{
    private RetrofitClient rfc;
    private String starttime;
    private String endtime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_orig);
        Button btnplot = (Button) findViewById(R.id.btnplot);
        btnplot.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                starttime=((EditText)findViewById(R.id.start_time_edittxt)).getText().toString();
                endtime=((EditText)findViewById(R.id.end_time_edittxt)).getText().toString();
                OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
                Retrofit retrofit = new Retrofit.Builder()
                        .baseUrl(getString(R.string.server_ip))
                        .addConverterFactory(GsonConverterFactory.create())
                        .client(getUnsafeOkHttpClient())
                        .build();
                rfc=retrofit.create(RetrofitClient.class);
                Map<String, String> fields = new HashMap<>();
                fields.put("starttime",starttime);
                fields.put("endtime",endtime);
                Call<PostGraph> call = rfc.createPost(fields);
                call.enqueue(new Callback<PostGraph>() {
                    @Override
                    public void onResponse(Call<PostGraph> call, Response<PostGraph> response) {
                        if (!response.isSuccessful()) {
                            return;
                        }
                        //Intent startIntent    = new Intent(getApplicationContext(),Image_slider.class);
                        Intent startIntent    = new Intent(getApplicationContext(),graph_orig_plot.class);
                        startActivity(startIntent);
                    }

                    @Override
                    public void onFailure(Call<PostGraph> call, Throwable t) {
                    }
                });
            }
        });
    }
    //the following function is used to make the app ignore the fact our server doesn't have certificate.
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
