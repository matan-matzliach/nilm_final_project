package com.example.nilmapp0;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class settingsActivity extends AppCompatActivity {
    private Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        spinner= (Spinner) findViewById(R.id.currency_spinner);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        EditText et=(EditText)findViewById(R.id.Price_edittxt);
        et.setText(Float.toString(((globalVars)getApplicationContext()).getPrice()));
        int spinnerPosition = adapter.getPosition( ((globalVars)getApplicationContext()).getCurrency());
        spinner.setSelection(spinnerPosition);
        Button btnsubmit = (Button) findViewById(R.id.btnsubmit);
        btnsubmit.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                ((globalVars) getApplicationContext()).setCurrency(spinner.getSelectedItem().toString());
                ((globalVars) getApplicationContext()).setPrice(Float.parseFloat((et).getText().toString()));
                Toast.makeText(getApplicationContext(),"changes saved",Toast.LENGTH_SHORT).show();
            }
        });
    }
}