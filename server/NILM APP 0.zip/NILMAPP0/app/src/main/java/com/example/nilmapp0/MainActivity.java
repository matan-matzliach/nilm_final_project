package com.example.nilmapp0;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {
    //public static final String BASE_URL = "http://192.168.1.241:5000/";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Calendar rightNow = Calendar.getInstance();
        int currentHour = rightNow.get(Calendar.HOUR_OF_DAY);
        System.out.println("CUR: "+currentHour);
        if(currentHour>=6 && currentHour<12){
            Toast.makeText(this,"Good morning!",Toast.LENGTH_SHORT).show();
        }
        else if(currentHour>=12 && currentHour<16){
            Toast.makeText(this,"Good day!",Toast.LENGTH_SHORT).show();
        }
        else if(currentHour>=16 && currentHour<19){
            Toast.makeText(this,"Good afternoon!",Toast.LENGTH_SHORT).show();
        }
        else if(currentHour>=19 && currentHour<22){
            Toast.makeText(this,"Good evening!",Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this,"Good night!",Toast.LENGTH_SHORT).show();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button about = (Button) findViewById(R.id.about);
        about.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(),Main2ActivityAbout.class);
                startActivity(startIntent);
            }
        });
        Button data = (Button) findViewById(R.id.dataBtn);
        data.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(),choose_statistics_options.class);
                startActivity(startIntent);
            }
        });
        Button addrem = (Button) findViewById(R.id.addrem);
        addrem.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(), AddOrRemoveChooseActivity.class);
                startActivity(startIntent);
            }
        });
        Button settings = (Button) findViewById(R.id.settingsBtn);
        settings.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent settingIntent    = new Intent(getApplicationContext(),settingsActivity.class);
                startActivity(settingIntent);
            }
        });
        //Calendar c=Calendar.getInstance();
       initWorker();
    }

    private void initWorker() {
        /*Data data = new Data.Builder()
                .putString("server_ip", getString(R.string.server_ip))
                .build();
        Constraints constraints = new Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED) // for WIFI
//                .setRequiresBatteryNotLow(true)
//                .setRequiresCharging(true)
                .build();

        PeriodicWorkRequest periodicWorkRequest = new PeriodicWorkRequest.Builder(
                workerclass.class,
                5,
                TimeUnit.MINUTES
        )
                .setConstraints(constraints)
                .setInputData(data)
                .addTag("check for new devices")
                .build();*/
       /* OneTimeWorkRequest periodicWorkRequest = new OneTimeWorkRequest.Builder(workerclass.class)
//                .setInitialDelay(5, TimeUnit.HOURS)
                .setConstraints(constraints)
                .setInputData(data)
                .addTag("check for new devices")
                .build();*/

        //WorkManager.getInstance().enqueue(periodicWorkRequest);*/
            Calendar c=Calendar.getInstance();
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(this, AlertReceiver.class);
            intent.putExtra("server_ip",getString(R.string.server_ip));
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);
            if (c.before(Calendar.getInstance())) {
                c.add(Calendar.DATE, 1);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,  SystemClock.elapsedRealtime()+10000,5*60*1000, pendingIntent);
                System.out.println("HHHHHHHHHHHHHHHHHHH");
            }



    }

}
