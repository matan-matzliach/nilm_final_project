package com.example.nilmapp0;

public class removePost {
    private String name;
    private String success;

    @Override
    public String toString() {
        return "removePost{" +
                "name='" + name + '\'' +
                ", success='" + success + '\'' +
                '}';
    }

    public removePost(String name, String success) {
        this.name = name;
        this.success = success;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }
}
