package com.example.nilmapp0;
//a class for the post request of the cost graph
public class CostPost {
    private float price;
    private String currency;
    private int months;

    public CostPost(float price, String currency, int months) {
        this.price = price;
        this.currency = currency;
        this.months = months;
    }

    @Override
    public String toString() {
        return "CostPost{" +
                "price=" + price +
                ", currency='" + currency + '\'' +
                ", months=" + months +
                '}';
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        this.months = months;
    }
}
