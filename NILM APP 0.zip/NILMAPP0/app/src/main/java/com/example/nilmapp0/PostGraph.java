package com.example.nilmapp0;
//a post class for the powergraph
public class PostGraph{
    private String starttime;
    private String endtime;

    public String getStarttime() {
        return starttime;
    }

    public void setStarttime(String starttime) {
        this.starttime = starttime;
    }

    public String getEndtime() {
        return endtime;
    }

    public void setEndtime(String endtime) {
        this.endtime = endtime;
    }

    public PostGraph(String startindex, String endindex) {
        this.starttime = startindex;
        this.endtime = endindex;
    }

    @Override
    public String toString() {
        return "PostGraph{" +
                "startindex='" + starttime + '\'' +
                ", endindex='" + endtime + '\'' +
                '}';
    }
}
