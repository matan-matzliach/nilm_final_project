package com.example.nilmapp0;

import android.app.Application;
//global app variables used to store price of power
public class globalVars extends Application {

    private String currency="USD";
    private float price=1;

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

}