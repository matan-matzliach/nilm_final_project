package com.example.nilmapp0;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.load.engine.DiskCacheStrategy;

public class ImageFragmentGraph extends Fragment {
    private ImageView image;

    public ImageView getImage() {
        return image;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_image_graph,container,false);
        image= (ImageView) view.findViewById(R.id.graphImage);
        Bundle bundle = getArguments();
        if(null!=bundle){
            String  url = bundle.getString("imageUrl","");
            GlideApp.with(getActivity())
                    .asBitmap()
                    .load(url)
                    .diskCacheStrategy(DiskCacheStrategy.NONE )
                    .skipMemoryCache(true)
                    .into(image);
        }

        return view;
    }

}
