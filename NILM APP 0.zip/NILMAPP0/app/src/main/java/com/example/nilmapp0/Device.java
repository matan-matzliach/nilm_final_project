package com.example.nilmapp0;
//a class to represent the device in the app (used mainly ion the settings of the power per device graph)
import java.io.Serializable;

public class Device implements Serializable {
    private String deviceName;
    private boolean use;

    @Override
    public String toString() {
        return deviceName;
    }

    public Device(String deviceName, boolean use) {
        this.deviceName = deviceName;
        this.use = use;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public boolean isUse() {
        return use;
    }

    public void setUse(boolean use) {
        this.use = use;
    }
}
