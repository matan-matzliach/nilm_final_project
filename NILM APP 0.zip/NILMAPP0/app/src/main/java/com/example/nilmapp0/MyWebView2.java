package com.example.nilmapp0;

import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

public class MyWebView2 extends AppCompatActivity {//a webview activity that takes you to our github page
    private WebView webView2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_web_view2);
        webView2=(WebView) findViewById(R.id.webView2);
        webView2.setWebViewClient(new WebViewClient());
        webView2.loadUrl("https://github.com/matan-matzliach/nilm_final_project");
    }
}