package com.example.nilmapp0;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class choose_statistics_options extends AppCompatActivity {
//a menu to chose what type of data you want to see
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choose_statistics_options);
        Button Pgraphtbl = (Button) findViewById(R.id.Pgraphtbl);
        Pgraphtbl.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(), graph_orig.class);
                startActivity(startIntent);
            }
        });
        Button Dgraphtbl = (Button) findViewById(R.id.Dgraphtbl);
        Dgraphtbl.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(), graph_devices.class);
                startActivity(startIntent);
            }
        });
        Button Cgraphtbl = (Button) findViewById(R.id.Cgraphtbl);
        Cgraphtbl.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(), graph_cost.class);
                startActivity(startIntent);
            }
        });
        Button devlist = (Button) findViewById(R.id.tablebtn);
        devlist.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(),DeviceListActivity.class);
                startActivity(startIntent);
            }
        });
    }
}
