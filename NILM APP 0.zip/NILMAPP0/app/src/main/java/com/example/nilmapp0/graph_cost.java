package com.example.nilmapp0;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
//a class for the settinggs of the cost graph
public class graph_cost extends AppCompatActivity {
    private RetrofitClient rfc;
    private Spinner spinner;
    private String currency;
    private float price;
    RadioButton radioButton;
    private int months;
    private RadioGroup radioGroup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //an activity for the cost graph settings
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graph_cost);
        radioGroup = findViewById(R.id.radiogroup);
        spinner= (Spinner) findViewById(R.id.period_spinner);
        //use arrayadapter for the spinner item of the period
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.time_periods, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        Button btnplot = (Button) findViewById(R.id.btnplot);
        checkButton(radioGroup);
        btnplot.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){//oncliclistener for the plot button
                String s=spinner.getSelectedItem().toString();//take the period from the spinner
                if(s.equals("1 month")){
                    months=1;
                }
                else if(s.equals("2 months")){
                    months=2;
                }
                else if(s.equals("3 months")){
                    months=3;
                }
                else if(s.equals("6 months")){
                    months=6;
                }
                else if(s.equals("1 year")){
                    months=12;
                }
                else if(s.equals("2 years")){
                    months=24;
                }

                OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder();
                Retrofit retrofit = new Retrofit.Builder()//use retrofit to send the information to the server
                        .baseUrl(getString(R.string.server_ip))
                        .addConverterFactory(GsonConverterFactory.create())
                        .client(getUnsafeOkHttpClient())
                        .build();
                rfc=retrofit.create(RetrofitClient.class);
                //send a cost post to the server requesting it to plot the graph
                CostPost post=new CostPost(price,currency,months);
                Call<CostPost> call = rfc.createPostCost(post);
                call.enqueue(new Callback<CostPost>() {//sen the post
                    @Override
                    public void onResponse(Call<CostPost> call, Response<CostPost> response) {
                        if (!response.isSuccessful()) {
                            return;
                        }
                        //Intent startIntent    = new Intent(getApplicationContext(),Image_slider.class);
                        Intent startIntent    = new Intent(getApplicationContext(),graph_cost_plot.class);//on response move to the grsph's activity
                        startActivity(startIntent);
                    }

                    @Override
                    public void onFailure(Call<CostPost> call, Throwable t) {
                    }
                });
            }
        });
    }
    public void checkButton(View v) {//a function for handling the radio group
        int radioId = radioGroup.getCheckedRadioButtonId();
        radioButton = findViewById(radioId);
        if(radioButton.getText().equals("KWH")){
            currency = "KWH";
            price= (float) 1.0;
        }
        else{
            currency = ((globalVars)getApplicationContext()).getCurrency();
            price=((globalVars)getApplicationContext()).getPrice();
        }

    }
    //the following function is used to make the app ignore the fact our server doesn't have certificate.
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}