package com.example.nilmapp0;

import java.util.ArrayList;

//a class for the post request of the cost graph
public class CostPost {
    private float price;
    private String currency;
    private int months;
    private ArrayList<String> devices_to_plot;

    public CostPost(float price, String currency, int months, ArrayList<String> devices_to_plot) {
        this.price = price;
        this.currency = currency;
        this.months = months;
        this.devices_to_plot = devices_to_plot;
    }

    @Override
    public String toString() {
        return "CostPost{" +
                "price=" + price +
                ", currency='" + currency + '\'' +
                ", months=" + months +
                ", devices_to_plot=" + devices_to_plot +
                '}';
    }

    public ArrayList<String> getDevices_to_plot() {
        return devices_to_plot;
    }

    public void setDevices_to_plot(ArrayList<String> devices_to_plot) {
        this.devices_to_plot = devices_to_plot;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        this.months = months;
    }
}
