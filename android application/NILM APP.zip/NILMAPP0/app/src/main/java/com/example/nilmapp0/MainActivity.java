package com.example.nilmapp0;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {//the main page of our app
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Calendar rightNow = Calendar.getInstance();
        int currentHour = rightNow.get(Calendar.HOUR_OF_DAY);
        //a toast massage to welcome the user
        if(currentHour>=6 && currentHour<12){
            Toast.makeText(this,"Good morning!",Toast.LENGTH_SHORT).show();
        }
        else if(currentHour>=12 && currentHour<16){
            Toast.makeText(this,"Good day!",Toast.LENGTH_SHORT).show();
        }
        else if(currentHour>=16 && currentHour<19){
            Toast.makeText(this,"Good afternoon!",Toast.LENGTH_SHORT).show();
        }
        else if(currentHour>=19 && currentHour<22){
            Toast.makeText(this,"Good evening!",Toast.LENGTH_SHORT).show();
        }
        else{
            Toast.makeText(this,"Good night!",Toast.LENGTH_SHORT).show();
        }
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //onclicklisteners for the buttons in the page
        Button about = (Button) findViewById(R.id.about);
        about.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(),Main2ActivityAbout.class);
                startActivity(startIntent);
            }
        });
        Button data = (Button) findViewById(R.id.dataBtn);
        data.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(),choose_statistics_options.class);
                startActivity(startIntent);
            }
        });
        Button addrem = (Button) findViewById(R.id.addrem);
        addrem.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent startIntent    = new Intent(getApplicationContext(), AddOrRemoveChooseActivity.class);
                startActivity(startIntent);
            }
        });
        Button settings = (Button) findViewById(R.id.settingsBtn);
        settings.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent settingIntent    = new Intent(getApplicationContext(),settingsActivity.class);
                startActivity(settingIntent);
            }
        });
       initWorker();
    }

    private void initWorker() {//inititalize a worker for the alarm manager to send an ack to the server every 5 minutes
            Calendar c=Calendar.getInstance();
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            Intent intent = new Intent(this, AlertReceiver.class);
        String ip =  ((globalVars)getApplicationContext()).getIp();
            intent.putExtra("server_ip",ip);
            PendingIntent pendingIntent = PendingIntent.getBroadcast(this, 1, intent, 0);
            if (c.before(Calendar.getInstance())) {
                c.add(Calendar.DATE, 1);
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
                alarmManager.setRepeating(AlarmManager.RTC_WAKEUP,  SystemClock.elapsedRealtime()+10000,5*60*1000, pendingIntent);
            }



    }

}
