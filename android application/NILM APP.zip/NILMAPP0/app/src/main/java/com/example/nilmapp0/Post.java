package com.example.nilmapp0;
//a post class for the post stating if a new device was detected or not
public class Post {
    private String needed;
    private DevicePost dev;

    @Override
    public String toString() {
        return "Post{" +
                "needed='" + needed + '\'' +
                ", dev=" + dev +
                '}';
    }

    public String getNeeded() {
        return needed;
    }

    public void setNeeded(String needed) {
        this.needed = needed;
    }

    public DevicePost getDev() {
        return dev;
    }

    public void setDev(DevicePost dev) {
        this.dev = dev;
    }

    public Post(String needed, DevicePost dev) {
        this.needed = needed;
        this.dev = dev;
    }
}
