package com.example.nilmapp0;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class settingsActivity extends AppCompatActivity {
    private Spinner spinner;
    //settings activity for changeing the price of electricity known to the application for the user to have
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        spinner= (Spinner) findViewById(R.id.currency_spinner);//spinner for the currecny
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.Currencies, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        EditText et=(EditText)findViewById(R.id.Price_edittxt);
        et.setText(Float.toString(((globalVars)getApplicationContext()).getPrice()));
        EditText etip=(EditText)findViewById(R.id.IP_eddittext);
        etip.setText(((globalVars)getApplicationContext()).getIponly());
        int spinnerPosition = adapter.getPosition( ((globalVars)getApplicationContext()).getCurrency());
        spinner.setSelection(spinnerPosition);
        Button btnsubmit = (Button) findViewById(R.id.btnsubmit);
        btnsubmit.setOnClickListener(new View.OnClickListener(){//an onclick listener for updating the settings
            @Override
            public void onClick(View v){
                ((globalVars) getApplicationContext()).setCurrency(spinner.getSelectedItem().toString());
                ((globalVars) getApplicationContext()).setPrice(Float.parseFloat((et).getText().toString()));
                ((globalVars) getApplicationContext()).setIponly((etip).getText().toString());
                ((globalVars) getApplicationContext()).setIp("https://"+((globalVars)getApplicationContext()).getIponly()+":5000/");
                Toast.makeText(getApplicationContext(),"changes saved",Toast.LENGTH_SHORT).show();//toast massage to inform the user that the changes were saved.
            }
        });
    }
}