package com.example.nilmapp0;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RemoveDevice extends AppCompatActivity implements RemoveDialog.RemoveDialogListener {
    private TextView servers_ans;
//an activity for the user to remove a device
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_remove_device);
        Button remBtn=(Button) findViewById(R.id.remBtn);
        remBtn.setOnClickListener(new View.OnClickListener() {//an onclicklistener for the remove button
            @Override
            public void onClick(View v) {
                remove();
            }
        });
    }
    protected void remove(){//shows the remove dialog
        RemoveDialog dialog = new RemoveDialog();
        dialog.show(getSupportFragmentManager(), "dialog");
    }
    @Override
    public void onYesClicked() {//if the user chose yes in the remove dialog it removes the device from the list
        EditText text = (EditText)findViewById(R.id.add_or_rem);
        servers_ans = (TextView) findViewById(R.id.answer_to_add_rem);
        String ip =  ((globalVars)getApplicationContext()).getIp();
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(ip)
                .addConverterFactory(GsonConverterFactory.create())
                .client(getUnsafeOkHttpClient())
                .build();
        RetrofitClient rfc=retrofit.create(RetrofitClient.class);
        String value = text.getText().toString();
        removePost p= new removePost(value,"yes");
        Call<removePost> call = rfc.remove_device(p);
        call.enqueue(new Callback<removePost>() {//sends the server a post request asking it to remove the device
            @Override
            public void onResponse(Call<removePost> call, Response<removePost> response) {
                if (!response.isSuccessful()) {
                    return;
                }
                removePost ans = response.body();
                if(ans.getSuccess().equals("yes")){
                    servers_ans.setText("Device removed successfully");
                }
                else{
                    servers_ans.setText("Device was not found in list");
                }
            }

            @Override
            public void onFailure(Call<removePost> call, Throwable t) {

            }
        });
    }
    //the following function is used to make the app ignore the fact our server doesn't have certificate.
    private static OkHttpClient getUnsafeOkHttpClient() {
        try {
            // Create a trust manager that does not validate certificate chains
            final TrustManager[] trustAllCerts = new TrustManager[] {
                    new X509TrustManager() {
                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] chain, String authType){
                        }

                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return new java.security.cert.X509Certificate[]{};
                        }
                    }
            };

            // Install the all-trusting trust manager
            final SSLContext sslContext = SSLContext.getInstance("SSL");
            sslContext.init(null, trustAllCerts, new java.security.SecureRandom());
            // Create an ssl socket factory with our all-trusting manager
            final SSLSocketFactory sslSocketFactory = sslContext.getSocketFactory();

            OkHttpClient.Builder builder = new OkHttpClient.Builder();
            builder.sslSocketFactory(sslSocketFactory);
            builder.hostnameVerifier(new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            });

            OkHttpClient okHttpClient = builder.build();
            return okHttpClient;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}