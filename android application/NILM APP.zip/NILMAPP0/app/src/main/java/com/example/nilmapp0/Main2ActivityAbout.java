package com.example.nilmapp0;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class Main2ActivityAbout extends AppCompatActivity {
//About page of the app
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2_about);
        //launch wikipedia page of NILM using a webview
        Button wikibtn = (Button) findViewById(R.id.wikibutton);
        wikibtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent gotowiki = new Intent(Main2ActivityAbout.this,MyWebView.class);
                if(gotowiki.resolveActivity(getPackageManager())!=null){
                    startActivity(gotowiki);
                }
            }
        });
        //launch github page of our project using a webview
        Button ourProjectbtn = (Button) findViewById(R.id.ourProjectbtn);
        ourProjectbtn.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent gotoProject = new Intent(Main2ActivityAbout.this,MyWebView2.class);
                if(gotoProject.resolveActivity(getPackageManager())!=null){
                    startActivity(gotoProject);
                }
            }
        });
    }

}
