package com.example.nilmapp0;

import android.app.Application;
//global app variables used to store price of power
public class globalVars extends Application {

    private String currency="USD";

    public String getIponly() {
        return iponly;
    }

    public void setIponly(String iponly) {
        this.iponly = iponly;
    }

    private float price=1;
    private String iponly="192.168.1.242";
    private String ip="https://192.168.1.242:5000/";

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = price;
    }

}