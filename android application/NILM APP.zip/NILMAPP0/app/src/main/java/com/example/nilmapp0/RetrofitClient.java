package com.example.nilmapp0;

import java.util.List;
import java.util.Map;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.FieldMap;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface RetrofitClient {//a retrofit interface for communicating with the server
    @FormUrlEncoded
    @POST("nilmgraph_power")
    Call<PostGraph> createPost(@FieldMap Map<String, String> fields);//sends a requset to the server that plots the power graph
    @POST("nilmgraph_cost")
    Call<CostPost> createPostCost(@Body CostPost p);//sends a requset to the server that plots the cost graph
    @POST("nilmgraph_devices")
    Call<DevicesPostplot> createPostDevice(@Body DevicesPostplot p);//sends a requset to the server that plots the power per device graph
    @FormUrlEncoded
    @POST("app")
    Call<Post> sendAck(@FieldMap Map<String, String> fields);//sends a regular ack to the server to make it check for new device in the network

    @GET("get_device_list")
    Call<List<DevicePost>> getDevicePosts();//asks the server for the device list
    @POST("add_device_json")
    Call<DevicePost> add_device(@Body DevicePost p);//tells the server to add a device to the list
    @POST("remove_device_json")
    Call<removePost> remove_device(@Body removePost p);//tells the server to remove a device from the list
    //@GET("{imageName}")
    //void getImage(@Path("imageName") String imageName, Callback<Response> callback);
}
