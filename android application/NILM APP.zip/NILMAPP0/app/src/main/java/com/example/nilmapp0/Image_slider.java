package com.example.nilmapp0;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.viewpager.widget.ViewPager;

import com.google.android.material.tabs.TabLayout;

import java.util.ArrayList;


public class Image_slider extends AppCompatActivity {
    private int STORAGE_PERMISSION_CODE = 1;
    private TabLayout tabSLayout;
    private ViewPager graphsViewPager;
    private ViewPagerAdaapter adapter;
    private ArrayList<String> urls= new ArrayList<>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_slider);
        adapter=new ViewPagerAdaapter(getSupportFragmentManager(),0);
        tabSLayout=(TabLayout)findViewById(R.id.tabLayout);
        graphsViewPager=(ViewPager) findViewById(R.id.graphsViewPaper);
        graphsViewPager.setAdapter(adapter);
        tabSLayout.setupWithViewPager(graphsViewPager);
        intiurls();
        ArrayList<ImageFragmentGraph> fragments = new ArrayList();
        for(int i=0;i<4;i++){
            ImageFragmentGraph imageFragment = new ImageFragmentGraph();
            Bundle bundle = new Bundle();
            bundle.putString("imageUrl",urls.get(i));
            imageFragment.setArguments(bundle);
            fragments.add(imageFragment);
        }
        adapter.setFragments(fragments);
        Button saveImg = (Button) findViewById(R.id.saveimagebtn);
        saveImg.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if (ContextCompat.checkSelfPermission(Image_slider.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    ImageView imgToSave=adapter.getItem(tabSLayout.getSelectedTabPosition()).getImage();
                    imgToSave.buildDrawingCache();
                    Bitmap bm=imgToSave.getDrawingCache();
                } else {
                    requestStoragePermission();
                }

            }
        });
    }
    private void requestStoragePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)) {
            new AlertDialog.Builder(this)
                    .setTitle("Permission needed")
                    .setMessage("This permission is needed because of this and that")
                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            ActivityCompat.requestPermissions(Image_slider.this,
                                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
                        }
                    })
                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create().show();
        } else {
            ActivityCompat.requestPermissions(this,
                    new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE}, STORAGE_PERMISSION_CODE);
        }
    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == STORAGE_PERMISSION_CODE)  {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void intiurls(){
        String ip =  ((globalVars)getApplicationContext()).getIp();
        urls.add(ip+"static//plots/general_graphs/I.png");
        System.out.println("TINY");
        urls.add(ip+"static//plots/general_graphs/I_THD.png");
        System.out.println("TINYO");
        urls.add(ip+"static//plots/general_graphs/P_KW.png");
        System.out.println("TINA");
        urls.add(ip+"static//plots/general_graphs/P_KVAR.png");
        System.out.println("TINE");

    }

}